import React from "react";
import useCartStore from "../store/cartStore";

const Cart = () => {
  const { cart, removeFromCart, clearCart } = useCartStore();

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Shopping Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between p-2 border-b">
              <span>{item.name} (x{item.qty})</span>
              <button
                onClick={() => removeFromCart(item.id)}
                className="text-red-500"
              >
                Remove
              </button>
            </div>
          ))}
          <button
            onClick={clearCart}
            className="mt-4 px-4 py-2 bg-red-500 text-white rounded-lg"
          >
            Clear Cart
          </button>
        </div>
      )}
    </div>
  );
};

export default Cart;
