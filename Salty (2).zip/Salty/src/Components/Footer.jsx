import { FaInstagram, FaFacebookF, FaTwitter, FaLinkedin } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-purple-200 text-gray-800 py-10 text-sm">
      <div className="max-w-6xl mx-auto px-5">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 fixxed md:grid-cols-3 gap-8 border-b border-gray-300 pb-6">
          
          {/* Column 1: All Jewellery */}
          <div>
            <h2 className="text-lg font-semibold mb-3">All Jewellery</h2>
            <ul className="space-y-2">
              <li><a href="#">Valentine’s Day</a></li>
              <li><a href="#">Earrings</a></li>
              <li><a href="#">Rings</a></li>
              <li><a href="#">Necklaces</a></li>
              <li><a href="#">Bracelets</a></li>
              <li><a href="#">Gift Boxes</a></li>
              <li><a href="#">New Arrivals</a></li>
            </ul>
          </div>

          {/* Column 2: Reviews & Deals */}
          <div>
            <h2 className="text-lg font-semibold mb-3">Reviews and Deals</h2>
            <ul className="space-y-2">
              <li><a href="#">Offers and Deals</a></li>
              <li><a href="#">Happy Customers Gallery</a></li>
              <li><a href="#">Customer Reviews</a></li>
            </ul>
          </div>

          {/* Column 3: Join Our Community */}
          <div>
            <h2 className="text-lg font-semibold mb-3">Join Our Community</h2>
            <ul className="space-y-2">
              <li><a href="#">Affiliate Program</a></li>
              <li><a href="#">Fashion Blog</a></li>
              <li><a href="#">Just for Fun</a></li>
            </ul>
          </div>

        </div>

        {/* Sign Up and Save */}
        <div className="mt-6 border-b border-gray-300 pb-6">
          <h2 className="text-lg font-semibold mb-3">Sign Up and Save</h2>
          <p className="text-gray-600">Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
          <div className="mt-3 flex items-center">
            <input type="email" placeholder="Enter your email" 
              className="px-3 py-2 w-full max-w-sm border rounded-l-md" />
            <button className="bg-gray-900 text-white px-4 py-2 rounded-r-md">Subscribe</button>
          </div>
        </div>

        {/* Social Icons and Contact Info */}
        <div className="flex flex-wrap justify-between items-center mt-6">
          {/* Social Media Icons */}
          <div className="flex space-x-4">
            <a href="#"><FaInstagram className="text-xl hover:text-gray-600" /></a>
            <a href="#"><FaFacebookF className="text-xl hover:text-gray-600" /></a>
            <a href="#"><FaTwitter className="text-xl hover:text-gray-600" /></a>
            <a href="#"><FaLinkedin className="text-xl hover:text-gray-600" /></a>
          </div>

          {/* Contact Info */}
          <div className="text-gray-600">
            <p><strong>Salty E-Commerce Private Limited</strong></p>
            <p>queries@salty.co.in</p>
            <p><a href="#" className="text-blue-600">WhatsApp Us</a></p>
            <p>Pamposh Enclave, GK-1 Delhi – 110048</p>
          </div>
        </div>

        {/* Policies & Links */}
        <div className="mt-6 text-gray-600 text-sm">
          <ul className="flex flex-wrap gap-4 justify-center">
            <li><a href="#">About Us</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Service</a></li>
            <li><a href="#">Refund Policy</a></li>
            <li><a href="#">FAQs</a></li>
            <li><a href="#">Shipping Policy</a></li>
            <li><a href="#">Track Order</a></li>
          </ul>
        </div>

        {/* Jewellery by Colour */}
        <div className="mt-6 text-gray-600 text-sm border-t border-gray-300 pt-4">
          <h2 className="text-lg font-semibold mb-2">Women's Jewellery by Colour:</h2>
          <p>
            <a href="#" className="text-blue-600">Gold</a> | 
            <a href="#" className="text-blue-600"> Silver</a> | 
            <a href="#" className="text-blue-600"> Yellow</a> | 
            <a href="#" className="text-blue-600"> White</a> | 
            <a href="#" className="text-blue-600"> Pink</a> | 
            <a href="#" className="text-blue-600"> Purple</a> | 
            <a href="#" className="text-blue-600"> Brown</a> | 
            <a href="#" className="text-blue-600"> Red</a> | 
            <a href="#" className="text-blue-600"> Green</a> | 
            <a href="#" className="text-blue-600"> Rose Gold</a> | 
            <a href="#" className="text-blue-600"> Black</a> | 
            <a href="#" className="text-blue-600"> Copper</a> | 
            <a href="#" className="text-blue-600"> Blue</a> | 
            <a href="#" className="text-blue-600"> Beige</a> | 
            <a href="#" className="text-blue-600"> Grey</a> | 
            <a href="#" className="text-blue-600"> Turquoise</a> | 
            <a href="#" className="text-blue-600"> New Arrivals</a>
          </p>
        </div>

        {/* Payment Icons & Copyright */}
        <div className="mt-6 text-center text-gray-600">
          <p>© 2025 Salty Accessories. All Rights Reserved.</p>
          <p className="text-xs">Powered by Shopify</p>
        </div>

      </div>
    </footer>
  );
};

export default Footer;
