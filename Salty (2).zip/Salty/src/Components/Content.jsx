import React, { useEffect, useState } from "react";
import ContentDropdown from "./ContentDropdown";
import Loader from "./common/Loader";

const Content = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:5000/products");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <div><Loader /></div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <main className="pt-20 mx-10">
      {/* Product Content */}
      <div className="flex-1">
        <div className="flex justify-between items-center my-10 px-5 md:px-20">
          <h1 className="text-3xl font-serif font-semibold text-center mx-auto">
            New Launch
          </h1>
          <ContentDropdown />
        </div>

        {loading && <Loader />}

        <div className="container p-5 mx-5 px-5 sm:px-10 lg:px-2 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((item) => (
            <div key={item.id} className="border rounded-lg overflow-hidden shadow-lg bg-white flex flex-col items-start">
              <div className="w-full h-80"> {/* Image shifted to the left */}
                <img
                  src={`http://localhost:5000${item.image}`}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4 text-left"> {/* Aligned content to left */}
                <h2 className="text-2xl font-bold mb-2">{item.title}</h2>
                <p className="text-gray-700">{item.description}</p>
                <div className="flex gap-5">
                  <p className="text-gray-700 italic font-semibold">
                    <del>₹{item.price}</del>
                  </p>
                  <p className="text-gray-700">₹{item.discount_price}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};

export default Content;
