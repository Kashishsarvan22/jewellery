import React, { useEffect, useState, useContext } from "react";
import { FilterProvider } from "../Pages/FilterContext";

const ProductsPage = () => {
  const { filters } = useContext(FilterProvider);
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchFilteredProducts = async () => {
      let query = `http://192.168.29.85:5000/products?minPrice=${filters.priceRange[0]}&maxPrice=${filters.priceRange[1]}`;

      if (filters.categories.length > 0) query += `&category=${filters.categories.join(",")}`;
      if (filters.colors.length > 0) query += `&color=${filters.colors.join(",")}`;
      if (filters.materials.length > 0) query += `&material=${filters.materials.join(",")}`;

      try {
        const response = await fetch(query);
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchFilteredProducts();
  }, [filters]);

  return (
    <div className="ml-72 p-6 grid grid-cols-3 gap-6">
      {products.length > 0 ? (
        products.map((product) => (
          <div key={product.id} className="border p-4 rounded-lg shadow-lg">
            <img src={product.image} alt={product.name} className="w-full h-48 object-cover mb-2" />
            <h2 className="text-lg font-semibold">{product.name}</h2>
            <p className="text-gray-700">Rs. {product.price}</p>
          </div>
        ))
      ) : (
        <p>No products found</p>
      )}
    </div>
  );
};

export default ProductsPage;
