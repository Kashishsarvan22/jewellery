import Navbar from "./Components/Navbar";
import Content from "./Components/Content";
import Sidebar from "./Components/Sidebar";
import Footer from "./Components/Footer";

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navbar */}
      <Navbar />

      {/* Main Content Wrapper */}
      <div className="flex flex-1">
        {/* Sidebar */}
        <Sidebar className="w-64" />

        {/* Content */}
        <div className="flex-1 p-4 container ml-[15%]">
          <Content />
        </div>
      </div>

      {/* Footer Outside Main Content */}
      <Footer />
    </div>
  );
}

export default App;
