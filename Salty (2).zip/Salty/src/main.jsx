import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import Content from "./Components/Content.jsx";
import FilterPage from "./Components/Pages/FilterPage.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Router> 
       {/* ✅ Keep Routes in App.js */}
      <Routes>
            <Route path="/" element={<App />} />  
            <Route path="/Content" element={<Content />} />  
            <Route path="/filter/:filterType" element={<FilterPage />} />  
          </Routes>
    </Router>
  </StrictMode>
);
